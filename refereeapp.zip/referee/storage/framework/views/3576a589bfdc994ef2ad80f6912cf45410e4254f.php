<?php $__env->startSection('content'); ?>
  <h1 class="title">Fixtures</h1>

  <?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fixture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <ul>
    <li>
      <a href="/fixtures/<?php echo e($fixture->id); ?>">
      <?php echo e($fixture->homeTeam); ?> vs <?php echo e($fixture->awayTeam); ?>

    </a>
    </li>
  </ul>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <br />
  <a href="/fixtures/create">Create new Fixture</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>