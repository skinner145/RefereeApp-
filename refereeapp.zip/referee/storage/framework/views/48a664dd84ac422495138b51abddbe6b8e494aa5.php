<?php $__env->startSection('content'); ?>
<h1 class="title"><?php echo e($fixture->homeTeam); ?> vs <?php echo e($fixture->awayTeam); ?></h1>

<div class="content">
<?php echo e($fixture->location); ?>

</div>

<p>
    <a href="/fixtures/<?php echo e($fixture->id); ?>/edit">Edit</a>
</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>