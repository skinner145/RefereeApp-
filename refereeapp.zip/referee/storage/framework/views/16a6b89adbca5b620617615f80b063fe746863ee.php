<?php $__env->startSection('content'); ?>
  <h1 class="title">Edit Project</h1>

  <form method="POST" action="/fixtures/<?php echo e($fixture->id); ?>">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>

    <div class="field">
      <label class="label" for="homeTeam">Home Team</label>
        <div class="control">
          <input type="text" class="input" name="homeTeam" placeholder="Home Team" value="<?php echo e($fixture->homeTeam); ?>" required>
        </div>
    </div>

    <div class="field">
          <label class="label" for="awayTeam">Away Team</label>

        <div class="control">
          <input type="text" class="input" name="awayTeam" placeholder="Away Team" value="<?php echo e($fixture->awayTeam); ?>" required>
        </div>
    </div>

    <div class="field">
          <label class="label" for="location">Location</label>
        <div class="control">
          <input type="text" class="input" name="location" placeholder="location" value="<?php echo e($fixture->location); ?>" required>
        </div>
    </div>

      <div>
          <button type="submit" class="button is-link">Update</button>
      </div>
</form>


  <form method="POST" action="/fixtures/<?php echo e($fixture->id); ?>">
  <?php echo method_field('delete'); ?>
  <?php echo csrf_field(); ?>

      <div class="field">
          <button type="submit" class="button">Delete</button>
      </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>