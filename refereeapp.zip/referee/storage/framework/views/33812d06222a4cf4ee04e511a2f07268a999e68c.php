<?php $__env->startSection('content'); ?>
  <h1>Create a fixture</h1>

  <form method="POST" action="/fixtures">
    <?php echo e(csrf_field()); ?>

    <div>
        <input type="text" name="homeTeam" placeholder="Home Team" value="<?php echo e(old('homeTeam')); ?>">
    </div>

    <div>
        <input type="text" name="awayTeam" placeholder="Away Team" value="<?php echo e(old('awayTeam')); ?>">
    </div>

    <div>
        <input type="text" name="location" placeholder="location" value="<?php echo e(old('location')); ?>">
    </div>

    <div>
      <select name="club">
        <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


         </select>
    </div>

    <div>
        <button type="submit">Create</button>
    </div>

    <?php if($errors->any()): ?>
    <div class="notification is-danger">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>