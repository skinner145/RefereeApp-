@extends('layout')

@section('content')
<h1 class="title">{{$fixture->homeTeam}} vs {{$fixture->awayTeam}}</h1>

<div class="content">
{{$fixture->location}}
</div>

<p>
    <a href="/fixtures/{{$fixture->id}}/edit">Edit</a>
</p>
@endsection
