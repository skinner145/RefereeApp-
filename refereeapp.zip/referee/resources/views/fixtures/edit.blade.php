@extends('layout')

@section('content')
  <h1 class="title">Edit Project</h1>

  <form method="POST" action="/fixtures/{{ $fixture->id }}">
  @method('PATCH')
  @csrf

    <div class="field">
      <label class="label" for="homeTeam">Home Team</label>
        <div class="control">
          <input type="text" class="input" name="homeTeam" placeholder="Home Team" value="{{ $fixture->homeTeam}}" required>
        </div>
    </div>

    <div class="field">
          <label class="label" for="awayTeam">Away Team</label>

        <div class="control">
          <input type="text" class="input" name="awayTeam" placeholder="Away Team" value="{{ $fixture->awayTeam}}" required>
        </div>
    </div>

    <div class="field">
          <label class="label" for="location">Location</label>
        <div class="control">
          <input type="text" class="input" name="location" placeholder="location" value="{{ $fixture->location}}" required>
        </div>
    </div>

      <div>
          <button type="submit" class="button is-link">Update</button>
      </div>
</form>


  <form method="POST" action="/fixtures/{{ $fixture->id }}">
  @method('delete')
  @csrf

      <div class="field">
          <button type="submit" class="button">Delete</button>
      </div>
  </form>
@endsection
