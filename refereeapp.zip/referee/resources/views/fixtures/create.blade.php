@extends('layout')

@section('content')
  <h1>Create a fixture</h1>

  <!-- <form method="POST" action="/fixtures">
    {{ csrf_field() }}
    <div>
        <input type="text" name="homeTeam" placeholder="Home Team" value="{{old('homeTeam')}}">
    </div>

    <div>
        <input type="text" name="awayTeam" placeholder="Away Team" value="{{old('awayTeam')}}">
    </div>

    <div>
        <input type="text" name="location" placeholder="location" value="{{old('location')}}">
    </div>

    <div>
      <select name="club">
        @foreach ($clubs as $key =>$value)
          <option value="{{$key}}">{{$value}}</option>
        @endforeach


         </select>
    </div>

    <div>
        <button type="submit">Create</button>
    </div>

    @if ($errors->any())
    <div class="notification is-danger">
      @foreach ($errors->all() as $error)
        <li>{{$error}}</li>
      @endforeach
    </div>
    @endif
  </form> -->







{!! Form::open(['action' => 'FixturesController@store', 'method' => 'POST']) !!}

<!-- {{ Form::select('homeTeam', $clubs, null) }}

{{ Form::select('awayTeam', $clubs, null ) }} -->

{{ Form::label('homeTeam', 'Home Team' ) }}
{{ Form::select('homeTeam', $clubs, null, ['placeholder' => 'Home Team']) }}

{{ Form::label('awayTeam', 'Away Team') }}
{{ Form::select('awayTeam', $clubs, null, ['placeholder' => 'Away Team']) }}

{{ Form::label('location', 'Location') }}
{{ Form::select('location', $locations, null, ['placeholder' => 'Location']) }}

{{ Form::label('referee_id', 'Referee') }}
{{ Form::select('referee_id', $referees, null, ['placeholder' => 'Referee']) }}



  {{ Form::submit('Submit') }}




    {!! Form::close() !!}

@endsection
