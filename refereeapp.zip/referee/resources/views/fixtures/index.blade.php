@extends('layout')

@section('content')
  <h1 class="title">Fixtures</h1>

  @foreach ($fixtures as $fixture)
  <ul>
    <li>
      <a href="/fixtures/{{ $fixture->id }}">
      {{$fixture->homeTeam}} vs {{$fixture->awayTeam}}
    </a>
    </li>
  </ul>
  @endforeach

  <br />
  <a href="/fixtures/create">Create new Fixture</a>

@endsection
