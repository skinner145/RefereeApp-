<h1>You're an admin</h1>
<input type="checkbox" {{ $user->hasRole('User') ? 'checked' : '' }} name="role_user"
<input type="checkbox" {{ $user->hasRole('Admin') ? 'checked' : '' }} name="role_admin"
