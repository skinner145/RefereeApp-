<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Fixture;
use App\Club;
use DB;

class FixturesController extends Controller
{
    public function index(){
      $fixtures = Fixture::all();

      return view('fixtures.index', compact('fixtures'));
    }


    public function show(Fixture $fixture){


      return view('fixtures.show', compact('fixture'));
    }



    public function create(){


      $clubs = DB::table('clubs')->pluck("name", "name");
      $locations = DB::table('clubs')->pluck("location", "location");
      $referees = DB::table('referees')->pluck("name", "id");

      // $clubs = ['0' => 'Select a team'] + collect($clubs)->toArray();

      // $clubs = Clubs::pluck('name', 'id');

      return view('fixtures.create', compact('clubs', 'referees', 'locations', 'fixtures'));
    }


    public function store(Request $request){
      $attributes = request()->validate([
        'homeTeam' => ['required'],
        'awayTeam' => ['required',],
        'location' => ['required', 'min:3'],
        'referee_id' => ['required']
      ]);

      Fixture::create($attributes);

      // $this->validate($request, [
      //     'homeTeam' => 'required',
      //     'awayTeam' => 'required',
      //     'location' => 'required',
      //     'referee' => 'required'
      // ]);
      //
      // $fixture = new Fixture;
      // $fixture->homeTeam = $request->input('homeTeam');
      // $fixture->awayTeam = $request->input('awayTeam');
      // $fixture->location = $request->input('location');
      // $fixture->referee_id = $request->input('referee_id');
      // $fixture->save();

      return redirect('/fixtures');
    }


    public function edit(Fixture $fixture){

      return view('fixtures.edit', compact('fixture'));

    }


    public function update(Fixture $fixture){

      $fixture->update(request(['homeTeam', 'awayTeam', 'location']));

      return redirect('/fixtures');
    }


    public function destroy(Fixture $fixture){
      $fixture->delete();
      return redirect('/fixtures');
    }



}
